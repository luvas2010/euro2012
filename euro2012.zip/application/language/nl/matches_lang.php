<?php
$lang['matches']            = "Wedstrijden";
$lang['overview_matches']   = "Overzicht van alle wedstrijden";
$lang['match_number']       = "#";
$lang['group']              = "Groep";
$lang['home']               = "Thuis";
$lang['away']               = "Uit";
$lang['result']             = "Uitslag";
$lang['match_time']         = "Aftrap";
$lang['edit_match_result']  = "Bewerk Wedstrijd Uitslag";
$lang['predict_match']      = "Voorspel Uitslag";
$lang['edit_all_predictions'] = "Bewerk Alle Voorspellingen";
$lang['prediction_saved']    = "Voorspelling voor %s opgeslagen";
$lang['predicted']         = "Voorspeld";
$lang['scores_for_match']   = "Scores voor wedstrijd";
$lang['show_scores_for_match']   = "Laat zien!";
$lang['not_calculated_yet'] = "Nog niet berekend";

/* End of file matches_lang.php */
/* Location: ./application/language/nl/matches_lang.php */
