<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['all_shouts']								= 'Alle berichten';
$lang['shout_header']							= "%s zei op %s om %s uur:";
$lang['delete_shout']							= 'Verwijderen';

/* End of file sign_in_lang.php */
/* Location: ./application/language/nl/shouts_lang.php */