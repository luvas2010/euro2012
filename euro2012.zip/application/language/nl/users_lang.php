<?php

$lang['username']       = "Gebruikersnaam";

/* End of file standings_lang.php */
/* Location: ./application/language/english/standings_lang.php */
