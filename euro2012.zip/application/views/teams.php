
<div id="teams">
	<pre>
		<?php print_r($teams); ?>
	</pre>
		
</div>
