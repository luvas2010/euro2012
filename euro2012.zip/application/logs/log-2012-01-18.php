<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-18 15:29:11 --> 404 Page Not Found --> sign_in/index.php
ERROR - 2012-01-18 15:29:40 --> Could not find the language line "home"
ERROR - 2012-01-18 15:29:40 --> Could not find the language line "away"
ERROR - 2012-01-18 15:29:40 --> Could not find the language line "home"
ERROR - 2012-01-18 15:29:40 --> Could not find the language line "away"
ERROR - 2012-01-18 15:30:08 --> Could not find the language line "home"
ERROR - 2012-01-18 15:30:08 --> Could not find the language line "away"
ERROR - 2012-01-18 15:30:08 --> Could not find the language line "home"
ERROR - 2012-01-18 15:30:08 --> Could not find the language line "away"
ERROR - 2012-01-18 15:31:11 --> Severity: Notice  --> Undefined variable: account C:\xampp\htdocs\euro2012\application\views\template\template.php 31
ERROR - 2012-01-18 15:31:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\template\template.php 31
ERROR - 2012-01-18 15:31:11 --> Severity: Notice  --> Undefined variable: account C:\xampp\htdocs\euro2012\application\views\template\template.php 32
ERROR - 2012-01-18 15:31:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\template\template.php 32
ERROR - 2012-01-18 15:31:11 --> Severity: Notice  --> Undefined variable: account C:\xampp\htdocs\euro2012\application\views\template\template.php 69
ERROR - 2012-01-18 15:31:11 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\template\template.php 69
ERROR - 2012-01-18 15:31:11 --> Could not find the language line "email_from_address"
ERROR - 2012-01-18 15:35:08 --> Could not find the language line "email_from_address"
ERROR - 2012-01-18 15:50:04 --> Could not find the language line "home"
ERROR - 2012-01-18 15:50:04 --> Could not find the language line "away"
ERROR - 2012-01-18 15:50:04 --> Could not find the language line "home"
ERROR - 2012-01-18 15:50:04 --> Could not find the language line "away"
ERROR - 2012-01-18 15:51:37 --> Could not find the language line "home"
ERROR - 2012-01-18 15:51:37 --> Could not find the language line "away"
ERROR - 2012-01-18 15:51:37 --> Could not find the language line "home"
ERROR - 2012-01-18 15:51:37 --> Could not find the language line "away"
ERROR - 2012-01-18 15:53:52 --> Could not find the language line "home"
ERROR - 2012-01-18 15:53:52 --> Could not find the language line "away"
ERROR - 2012-01-18 15:53:52 --> Could not find the language line "home"
ERROR - 2012-01-18 15:53:52 --> Could not find the language line "away"
ERROR - 2012-01-18 17:59:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\template\template.php 33
ERROR - 2012-01-18 17:59:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\template\template.php 34
ERROR - 2012-01-18 17:59:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\template\template.php 71
ERROR - 2012-01-18 18:02:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:03:09 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:03:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:04:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:04:12 --> Could not find the language line "home"
ERROR - 2012-01-18 18:04:12 --> Could not find the language line "away"
ERROR - 2012-01-18 18:04:12 --> Could not find the language line "home"
ERROR - 2012-01-18 18:04:12 --> Could not find the language line "away"
ERROR - 2012-01-18 18:04:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:04:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:04:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:05:08 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 4
ERROR - 2012-01-18 18:06:57 --> Could not find the language line "home"
ERROR - 2012-01-18 18:06:57 --> Could not find the language line "away"
ERROR - 2012-01-18 18:06:57 --> Could not find the language line "home"
ERROR - 2012-01-18 18:06:58 --> Could not find the language line "away"
ERROR - 2012-01-18 18:10:53 --> Could not find the language line "home"
ERROR - 2012-01-18 18:10:53 --> Could not find the language line "away"
ERROR - 2012-01-18 18:10:53 --> Could not find the language line "home"
ERROR - 2012-01-18 18:10:53 --> Could not find the language line "away"
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:19:49 --> Could not find the language line ""
ERROR - 2012-01-18 18:30:59 --> Could not find the language line "ALL"
ERROR - 2012-01-18 18:31:07 --> Could not find the language line "ALL"
ERROR - 2012-01-18 18:31:14 --> Could not find the language line "ALL"
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 3 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 4 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 5 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 6 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 7 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 8 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 9 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 10 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 11 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 12 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 13 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 14 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 15 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 16 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 17 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 18 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 19 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 20 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 21 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 21 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 22 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 22 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 23 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 435
ERROR - 2012-01-18 18:33:45 --> Severity: Notice  --> Undefined offset: 23 C:\xampp\htdocs\euro2012\application\controllers\predictions.php 442
ERROR - 2012-01-18 18:33:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\euro2012\system\core\Exceptions.php:185) C:\xampp\htdocs\euro2012\application\libraries\MY_Session.php 73
ERROR - 2012-01-18 18:33:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\euro2012\system\core\Exceptions.php:185) C:\xampp\htdocs\euro2012\system\helpers\url_helper.php 546
ERROR - 2012-01-18 18:35:44 --> Could not find the language line "ALL"
ERROR - 2012-01-18 18:35:53 --> Could not find the language line "ALL"
ERROR - 2012-01-18 18:36:02 --> Could not find the language line "ALL"
ERROR - 2012-01-18 18:36:16 --> Could not find the language line "home"
ERROR - 2012-01-18 18:36:16 --> Could not find the language line "away"
ERROR - 2012-01-18 18:36:16 --> Could not find the language line "home"
ERROR - 2012-01-18 18:36:16 --> Could not find the language line "away"
ERROR - 2012-01-18 18:37:54 --> Could not find the language line "home"
ERROR - 2012-01-18 18:37:54 --> Could not find the language line "away"
ERROR - 2012-01-18 18:37:54 --> Could not find the language line "home"
ERROR - 2012-01-18 18:37:54 --> Could not find the language line "away"
ERROR - 2012-01-18 18:38:30 --> Could not find the language line "home"
ERROR - 2012-01-18 18:38:30 --> Could not find the language line "away"
ERROR - 2012-01-18 18:38:30 --> Could not find the language line "home"
ERROR - 2012-01-18 18:38:30 --> Could not find the language line "away"
ERROR - 2012-01-18 18:38:40 --> Query error: Duplicate entry 'test' for key 'message'
ERROR - 2012-01-18 18:38:44 --> Query error: Duplicate entry 'test' for key 'message'
ERROR - 2012-01-18 18:39:17 --> Query error: Duplicate entry 'test' for key 'message'
ERROR - 2012-01-18 18:42:19 --> Could not find the language line "home"
ERROR - 2012-01-18 18:42:19 --> Could not find the language line "away"
ERROR - 2012-01-18 18:42:19 --> Could not find the language line "home"
ERROR - 2012-01-18 18:42:19 --> Could not find the language line "away"
ERROR - 2012-01-18 18:42:37 --> Could not find the language line "home"
ERROR - 2012-01-18 18:42:37 --> Could not find the language line "away"
ERROR - 2012-01-18 18:42:37 --> Could not find the language line "home"
ERROR - 2012-01-18 18:42:37 --> Could not find the language line "away"
ERROR - 2012-01-18 18:42:51 --> Could not find the language line "home"
ERROR - 2012-01-18 18:42:51 --> Could not find the language line "away"
ERROR - 2012-01-18 18:42:51 --> Could not find the language line "home"
ERROR - 2012-01-18 18:42:51 --> Could not find the language line "away"
ERROR - 2012-01-18 18:43:27 --> Could not find the language line "home"
ERROR - 2012-01-18 18:43:27 --> Could not find the language line "away"
ERROR - 2012-01-18 18:43:27 --> Could not find the language line "home"
ERROR - 2012-01-18 18:43:27 --> Could not find the language line "away"
ERROR - 2012-01-18 18:43:43 --> Could not find the language line "home"
ERROR - 2012-01-18 18:43:43 --> Could not find the language line "away"
ERROR - 2012-01-18 18:43:43 --> Could not find the language line "home"
ERROR - 2012-01-18 18:43:43 --> Could not find the language line "away"
ERROR - 2012-01-18 18:47:34 --> Could not find the language line "home"
ERROR - 2012-01-18 18:47:34 --> Could not find the language line "away"
ERROR - 2012-01-18 18:47:34 --> Could not find the language line "home"
ERROR - 2012-01-18 18:47:34 --> Could not find the language line "away"
ERROR - 2012-01-18 18:47:40 --> 404 Page Not Found --> shoutbox/delete67
ERROR - 2012-01-18 18:47:59 --> Could not find the language line "home"
ERROR - 2012-01-18 18:47:59 --> Could not find the language line "away"
ERROR - 2012-01-18 18:47:59 --> Could not find the language line "home"
ERROR - 2012-01-18 18:47:59 --> Could not find the language line "away"
ERROR - 2012-01-18 18:48:03 --> Could not find the language line "home"
ERROR - 2012-01-18 18:48:03 --> Could not find the language line "away"
ERROR - 2012-01-18 18:48:03 --> Could not find the language line "home"
ERROR - 2012-01-18 18:48:03 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:32 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:32 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:32 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:32 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:38 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:38 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:38 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:38 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:43 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:43 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:43 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:43 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:46 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:46 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:46 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:46 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:48 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:48 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:48 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:48 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:49 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:49 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:49 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:49 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:50 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:50 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:50 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:50 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:51 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:51 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:51 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:51 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:52 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:52 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:52 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:52 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:55 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:55 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:55 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:55 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:56 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:56 --> Could not find the language line "away"
ERROR - 2012-01-18 18:49:56 --> Could not find the language line "home"
ERROR - 2012-01-18 18:49:56 --> Could not find the language line "away"
ERROR - 2012-01-18 18:50:49 --> Could not find the language line "home"
ERROR - 2012-01-18 18:50:49 --> Could not find the language line "away"
ERROR - 2012-01-18 18:50:49 --> Could not find the language line "home"
ERROR - 2012-01-18 18:50:49 --> Could not find the language line "away"
ERROR - 2012-01-18 19:18:37 --> Query error: Duplicate column name 'payed'
ERROR - 2012-01-18 19:23:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'DROP COLUMN `payed`' at line 1
ERROR - 2012-01-18 19:23:52 --> Query error: Can't DROP 'payed'; check that column/key exists
ERROR - 2012-01-18 19:28:35 --> Could not find the language line "home"
ERROR - 2012-01-18 19:28:35 --> Could not find the language line "away"
ERROR - 2012-01-18 19:28:35 --> Could not find the language line "home"
ERROR - 2012-01-18 19:28:35 --> Could not find the language line "away"
ERROR - 2012-01-18 19:30:26 --> Could not find the language line "home"
ERROR - 2012-01-18 19:30:26 --> Could not find the language line "away"
ERROR - 2012-01-18 19:30:26 --> Could not find the language line "home"
ERROR - 2012-01-18 19:30:26 --> Could not find the language line "away"
ERROR - 2012-01-18 19:31:19 --> Could not find the language line "home"
ERROR - 2012-01-18 19:31:19 --> Could not find the language line "away"
ERROR - 2012-01-18 19:31:19 --> Could not find the language line "home"
ERROR - 2012-01-18 19:31:19 --> Could not find the language line "away"
ERROR - 2012-01-18 19:31:22 --> Could not find the language line "home"
ERROR - 2012-01-18 19:31:22 --> Could not find the language line "away"
ERROR - 2012-01-18 19:31:22 --> Could not find the language line "home"
ERROR - 2012-01-18 19:31:22 --> Could not find the language line "away"
ERROR - 2012-01-18 19:31:51 --> Could not find the language line "home"
ERROR - 2012-01-18 19:31:51 --> Could not find the language line "away"
ERROR - 2012-01-18 19:31:51 --> Could not find the language line "home"
ERROR - 2012-01-18 19:31:51 --> Could not find the language line "away"
ERROR - 2012-01-18 19:49:21 --> Could not find the language line "home"
ERROR - 2012-01-18 19:49:21 --> Could not find the language line "away"
ERROR - 2012-01-18 19:49:21 --> Could not find the language line "home"
ERROR - 2012-01-18 19:49:21 --> Could not find the language line "away"
ERROR - 2012-01-18 19:50:13 --> Could not find the language line "home"
ERROR - 2012-01-18 19:50:13 --> Could not find the language line "away"
ERROR - 2012-01-18 19:50:13 --> Could not find the language line "home"
ERROR - 2012-01-18 19:50:13 --> Could not find the language line "away"
ERROR - 2012-01-18 19:51:07 --> Could not find the language line "home"
ERROR - 2012-01-18 19:51:07 --> Could not find the language line "away"
ERROR - 2012-01-18 19:51:07 --> Could not find the language line "home"
ERROR - 2012-01-18 19:51:07 --> Could not find the language line "away"
ERROR - 2012-01-18 19:51:20 --> Could not find the language line "home"
ERROR - 2012-01-18 19:51:20 --> Could not find the language line "away"
ERROR - 2012-01-18 19:51:20 --> Could not find the language line "home"
ERROR - 2012-01-18 19:51:20 --> Could not find the language line "away"
ERROR - 2012-01-18 19:51:57 --> Could not find the language line "home"
ERROR - 2012-01-18 19:51:57 --> Could not find the language line "away"
ERROR - 2012-01-18 19:51:57 --> Could not find the language line "home"
ERROR - 2012-01-18 19:51:57 --> Could not find the language line "away"
ERROR - 2012-01-18 19:52:07 --> Could not find the language line "home"
ERROR - 2012-01-18 19:52:07 --> Could not find the language line "away"
ERROR - 2012-01-18 19:52:07 --> Could not find the language line "home"
ERROR - 2012-01-18 19:52:07 --> Could not find the language line "away"
ERROR - 2012-01-18 19:54:31 --> Could not find the language line "home"
ERROR - 2012-01-18 19:54:31 --> Could not find the language line "away"
ERROR - 2012-01-18 19:54:31 --> Could not find the language line "home"
ERROR - 2012-01-18 19:54:31 --> Could not find the language line "away"
ERROR - 2012-01-18 19:54:40 --> Could not find the language line "home"
ERROR - 2012-01-18 19:54:40 --> Could not find the language line "away"
ERROR - 2012-01-18 19:54:40 --> Could not find the language line "home"
ERROR - 2012-01-18 19:54:40 --> Could not find the language line "away"
ERROR - 2012-01-18 19:55:09 --> Could not find the language line "home"
ERROR - 2012-01-18 19:55:09 --> Could not find the language line "away"
ERROR - 2012-01-18 19:55:09 --> Could not find the language line "home"
ERROR - 2012-01-18 19:55:09 --> Could not find the language line "away"
ERROR - 2012-01-18 20:15:54 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 20:15:54 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 20:16:00 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 20:16:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 20:16:02 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 20:16:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 20:16:19 --> 404 Page Not Found --> matches/edit_prediction
ERROR - 2012-01-18 20:16:23 --> 404 Page Not Found --> matches/edit_prediction
ERROR - 2012-01-18 20:18:59 --> 404 Page Not Found --> 
ERROR - 2012-01-18 20:19:24 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 20:20:29 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 20:20:34 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 20:20:34 --> Could not find the language line "team_home"
ERROR - 2012-01-18 20:20:34 --> Could not find the language line "team_away"
ERROR - 2012-01-18 20:20:34 --> Could not find the language line "bonus"
ERROR - 2012-01-18 20:21:49 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 20:21:58 --> 404 Page Not Found --> matches/edit_prediction
ERROR - 2012-01-18 20:22:55 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 20:28:06 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 21:09:12 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 21:09:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-18 21:31:19 --> Could not find the language line "overview_of_points_for"
ERROR - 2012-01-18 22:04:17 --> Could not find the language line "ALL"
ERROR - 2012-01-18 22:05:32 --> Could not find the language line "ALL"
ERROR - 2012-01-18 22:06:12 --> Could not find the language line "ALL"
