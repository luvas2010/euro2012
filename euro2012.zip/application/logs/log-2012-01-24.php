<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-24 18:53:07 --> Could not find the language line "home"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "away"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "home"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "away"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "home"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "away"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "home"
ERROR - 2012-01-24 18:53:07 --> Could not find the language line "away"
ERROR - 2012-01-24 18:53:37 --> Could not find the language line "email_from_address"
ERROR - 2012-01-24 12:56:28 --> Severity: Warning  --> date_default_timezone_get() [<a href='function.date-default-timezone-get'>function.date-default-timezone-get</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'America/New_York' for '-5.0/no DST' instead C:\xampp\htdocs\euro2012\application\views\admin\check_settings.php 15
ERROR - 2012-01-24 12:56:28 --> Severity: Warning  --> Unknown: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'America/New_York' for '-5.0/no DST' instead Unknown 0
ERROR - 2012-01-24 12:56:59 --> Could not find the language line "email_from_address"
ERROR - 2012-01-24 12:57:19 --> Could not find the language line "email_from_address"
ERROR - 2012-01-24 12:57:40 --> Could not find the language line "email_from_address"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "home"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "away"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "home"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "away"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "home"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "away"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "home"
ERROR - 2012-01-24 13:01:54 --> Could not find the language line "away"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "home"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "away"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "home"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "away"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "home"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "away"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "home"
ERROR - 2012-01-24 13:03:06 --> Could not find the language line "away"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "home"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "away"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "home"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "away"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "home"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "away"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "home"
ERROR - 2012-01-24 13:08:20 --> Could not find the language line "away"
ERROR - 2012-01-24 13:08:28 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:28 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:32 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:32 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:34 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:34 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:37 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:37 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:40 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:44 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-24 13:08:50 --> Could not find the language line "home"
ERROR - 2012-01-24 13:08:50 --> Could not find the language line "away"
ERROR - 2012-01-24 13:08:50 --> Could not find the language line "home"
ERROR - 2012-01-24 13:08:50 --> Could not find the language line "away"
ERROR - 2012-01-24 14:41:38 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:39 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:40 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:41 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:42 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:43 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:44 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:44 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:45 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:45 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:46 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:46 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:47 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:47 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:48 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:48 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:49 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:49 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:50 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:50 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:51 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:51 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:52 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:52 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:53 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:53 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:54 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:55 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:55 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:56 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:56 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:57 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:57 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:58 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:59 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:41:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:00 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:00 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:01 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:01 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:02 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:03 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 14:42:03 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1133
ERROR - 2012-01-24 15:00:56 --> Could not find the language line "home"
ERROR - 2012-01-24 15:00:56 --> Could not find the language line "away"
ERROR - 2012-01-24 15:00:56 --> Could not find the language line "home"
ERROR - 2012-01-24 15:00:56 --> Could not find the language line "away"
