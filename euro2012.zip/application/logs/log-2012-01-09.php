<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-09 16:37:05 --> Severity: Notice  --> Undefined property: stdClass::$payed C:\xampp\htdocs\euro2012\application\views\home.php 7
ERROR - 2012-01-09 16:37:55 --> 404 Page Not Found --> 
ERROR - 2012-01-09 16:38:13 --> Could not find the language line "standings"
ERROR - 2012-01-09 16:39:12 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-09 16:39:14 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-09 17:02:55 --> Could not find the language line "standings"
ERROR - 2012-01-09 17:03:08 --> Could not find the language line "standings"
ERROR - 2012-01-09 17:03:45 --> Could not find the language line "standings"
ERROR - 2012-01-09 17:04:21 --> Could not find the language line "standings"
ERROR - 2012-01-09 17:04:21 --> Could not find the language line "average_goals"
ERROR - 2012-01-09 17:04:21 --> Could not find the language line "total_with_average"
ERROR - 2012-01-09 17:04:25 --> Could not find the language line "standings"
ERROR - 2012-01-09 17:05:06 --> Could not find the language line "standings"
ERROR - 2012-01-09 17:40:41 --> Severity: Notice  --> Undefined variable: percentage C:\xampp\htdocs\euro2012\application\views\home.php 61
ERROR - 2012-01-09 17:41:39 --> Could not find the language line "standings"
ERROR - 2012-01-09 18:12:30 --> Could not find the language line "standings"
ERROR - 2012-01-09 18:38:27 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\views\home.php 39
ERROR - 2012-01-09 18:38:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 39
ERROR - 2012-01-09 18:46:03 --> Severity: Warning  --> sprintf() [<a href='function.sprintf'>function.sprintf</a>]: Too few arguments C:\xampp\htdocs\euro2012\application\views\home.php 41
ERROR - 2012-01-09 18:46:14 --> Severity: Warning  --> sprintf() [<a href='function.sprintf'>function.sprintf</a>]: Too few arguments C:\xampp\htdocs\euro2012\application\views\home.php 41
ERROR - 2012-01-09 18:46:17 --> Severity: Warning  --> sprintf() [<a href='function.sprintf'>function.sprintf</a>]: Too few arguments C:\xampp\htdocs\euro2012\application\views\home.php 41
ERROR - 2012-01-09 18:57:14 --> Could not find the language line "money_distribution"
ERROR - 2012-01-09 18:57:14 --> Could not find the language line "number"
ERROR - 2012-01-09 18:57:14 --> Could not find the language line "number"
ERROR - 2012-01-09 18:57:14 --> Could not find the language line "number"
ERROR - 2012-01-09 18:57:37 --> Could not find the language line "money_distribution"
ERROR - 2012-01-09 18:57:37 --> Could not find the language line "winner"
ERROR - 2012-01-09 18:57:37 --> Could not find the language line "number"
ERROR - 2012-01-09 18:57:37 --> Could not find the language line "number"
ERROR - 2012-01-09 18:57:53 --> Could not find the language line "winner"
ERROR - 2012-01-09 18:57:53 --> Could not find the language line "number"
ERROR - 2012-01-09 18:57:53 --> Could not find the language line "number"
ERROR - 2012-01-09 18:59:17 --> Could not find the language line "winner"
ERROR - 2012-01-09 18:59:17 --> Could not find the language line "number"
ERROR - 2012-01-09 18:59:17 --> Could not find the language line "number"
ERROR - 2012-01-09 19:01:58 --> Could not find the language line "winner"
ERROR - 2012-01-09 19:01:58 --> Could not find the language line "number"
ERROR - 2012-01-09 19:01:58 --> Severity: Warning  --> Wrong parameter count for number_format() C:\xampp\htdocs\euro2012\application\views\home.php 53
ERROR - 2012-01-09 19:01:58 --> Could not find the language line "number"
ERROR - 2012-01-09 19:01:58 --> Severity: Warning  --> Wrong parameter count for number_format() C:\xampp\htdocs\euro2012\application\views\home.php 53
ERROR - 2012-01-09 19:02:13 --> Could not find the language line "winner"
ERROR - 2012-01-09 19:02:13 --> Could not find the language line "number"
ERROR - 2012-01-09 19:02:13 --> Could not find the language line "number"
ERROR - 2012-01-09 19:02:47 --> Could not find the language line "winner"
ERROR - 2012-01-09 19:02:47 --> Could not find the language line "number"
ERROR - 2012-01-09 19:02:47 --> Could not find the language line "number"
ERROR - 2012-01-09 19:06:50 --> 404 Page Not Found --> 
ERROR - 2012-01-09 19:11:54 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-09 19:11:55 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-09 19:12:28 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-09 19:12:29 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-09 19:22:58 --> Query error: Unknown column '' in 'where clause'
ERROR - 2012-01-09 19:36:40 --> Could not find the language line "standings"
ERROR - 2012-01-09 19:36:49 --> Could not find the language line "standings"
ERROR - 2012-01-09 19:36:54 --> Could not find the language line "standings"
ERROR - 2012-01-09 19:36:58 --> Could not find the language line "standings"
ERROR - 2012-01-09 19:36:58 --> Could not find the language line "average_goals"
ERROR - 2012-01-09 19:36:58 --> Could not find the language line "total_with_average"
ERROR - 2012-01-09 19:37:03 --> Could not find the language line "home_goals"
ERROR - 2012-01-09 19:37:03 --> Could not find the language line "away_goals"
ERROR - 2012-01-09 19:37:13 --> Could not find the language line "standings"
ERROR - 2012-01-09 19:37:32 --> Could not find the language line "home_goals"
ERROR - 2012-01-09 19:37:32 --> Could not find the language line "away_goals"
ERROR - 2012-01-09 19:37:38 --> Could not find the language line "home_goals"
ERROR - 2012-01-09 19:37:38 --> Could not find the language line "away_goals"
ERROR - 2012-01-09 19:37:48 --> Could not find the language line "standings"
ERROR - 2012-01-09 19:46:07 --> Severity: Notice  --> Undefined variable: predcition C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 80
ERROR - 2012-01-09 19:46:07 --> Severity: Notice  --> Undefined variable: predcition C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 80
ERROR - 2012-01-09 19:46:07 --> Severity: Notice  --> Undefined variable: predcition C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 80
ERROR - 2012-01-09 19:46:07 --> Severity: Notice  --> Undefined variable: predcition C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 80
ERROR - 2012-01-09 19:48:35 --> Severity: Notice  --> Undefined index: A2 C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 86
ERROR - 2012-01-09 19:48:35 --> Severity: Notice  --> Undefined index: A1 C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 82
ERROR - 2012-01-09 20:21:09 --> Could not find the language line "standings"
ERROR - 2012-01-09 20:21:09 --> Could not find the language line "average_goals"
ERROR - 2012-01-09 20:21:09 --> Could not find the language line "total_with_average"
ERROR - 2012-01-09 21:02:47 --> Could not find the language line "standings"
ERROR - 2012-01-09 21:10:38 --> Could not find the language line "standings"
ERROR - 2012-01-09 21:11:25 --> Could not find the language line "standings"
ERROR - 2012-01-09 21:20:28 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-09 21:20:29 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-09 21:20:45 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-09 21:20:46 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-09 21:37:08 --> Severity: Notice  --> Undefined variable: chartdata C:\xampp\htdocs\euro2012\application\views\home.php 106
ERROR - 2012-01-09 21:37:08 --> Severity: Notice  --> Undefined index: number C:\xampp\htdocs\euro2012\application\views\home.php 106
ERROR - 2012-01-09 21:37:08 --> Severity: Notice  --> Undefined index: number C:\xampp\htdocs\euro2012\application\views\home.php 106
ERROR - 2012-01-09 21:37:08 --> Severity: Notice  --> Undefined index: number C:\xampp\htdocs\euro2012\application\views\home.php 106
ERROR - 2012-01-09 22:15:41 --> Could not find the language line "standings"
ERROR - 2012-01-09 22:22:32 --> Could not find the language line "standings"
