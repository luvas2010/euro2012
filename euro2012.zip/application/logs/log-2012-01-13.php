<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-13 15:56:36 --> Could not find the language line "home"
ERROR - 2012-01-13 15:56:36 --> Could not find the language line "away"
ERROR - 2012-01-13 15:56:36 --> Could not find the language line "home"
ERROR - 2012-01-13 15:56:36 --> Could not find the language line "away"
ERROR - 2012-01-13 15:57:32 --> Could not find the language line "home"
ERROR - 2012-01-13 15:57:32 --> Could not find the language line "away"
ERROR - 2012-01-13 15:57:32 --> Could not find the language line "home"
ERROR - 2012-01-13 15:57:32 --> Could not find the language line "away"
ERROR - 2012-01-13 15:58:27 --> Could not find the language line "home"
ERROR - 2012-01-13 15:58:27 --> Could not find the language line "away"
ERROR - 2012-01-13 15:58:27 --> Could not find the language line "home"
ERROR - 2012-01-13 15:58:27 --> Could not find the language line "away"
ERROR - 2012-01-13 15:59:16 --> Could not find the language line "home"
ERROR - 2012-01-13 15:59:16 --> Could not find the language line "away"
ERROR - 2012-01-13 15:59:16 --> Could not find the language line "home"
ERROR - 2012-01-13 15:59:16 --> Could not find the language line "away"
ERROR - 2012-01-13 15:59:28 --> Could not find the language line "home"
ERROR - 2012-01-13 15:59:28 --> Could not find the language line "away"
ERROR - 2012-01-13 15:59:28 --> Could not find the language line "home"
ERROR - 2012-01-13 15:59:28 --> Could not find the language line "away"
ERROR - 2012-01-13 16:00:33 --> Could not find the language line "home"
ERROR - 2012-01-13 16:00:33 --> Could not find the language line "away"
ERROR - 2012-01-13 16:00:33 --> Could not find the language line "home"
ERROR - 2012-01-13 16:00:33 --> Could not find the language line "away"
ERROR - 2012-01-13 16:00:41 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:00:41 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:02:12 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:02:13 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:02:21 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 16:02:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:02:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:03:09 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:03:09 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:21 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:21 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:33 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:33 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:40 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:40 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:48 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:48 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:55 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:09:55 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:10:00 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 16:10:28 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:10:28 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:10:38 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 16:11:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:11:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:12:20 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:12:20 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:13:06 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:13:06 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:13:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:13:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:14:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:14:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:14:24 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:14:24 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:15:46 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:15:46 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:16:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:16:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:17:08 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:17:08 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:20:18 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:20:18 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:24:58 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:25:08 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:25:12 --> 404 Page Not Found --> 
ERROR - 2012-01-13 16:26:07 --> 404 Page Not Found --> 
ERROR - 2012-01-13 16:27:51 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:28:22 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:28:27 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:30:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:31:27 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:35:33 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:35:39 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:35:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:35:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:36:36 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:36:43 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:36:49 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:36:55 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:36:58 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:37:01 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:37:03 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:37:07 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:37:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:37:12 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:45:04 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:45:16 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:49:55 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:50:15 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:50:43 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:51:33 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:51:38 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:51:41 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:51:46 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:51:54 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:52:06 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:55:36 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:55:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:56:12 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 804
ERROR - 2012-01-13 16:56:12 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 16:56:13 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:58:28 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:58:50 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 804
ERROR - 2012-01-13 16:58:50 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 16:58:51 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 16:59:51 --> Could not find the language line "home"
ERROR - 2012-01-13 16:59:51 --> Could not find the language line "away"
ERROR - 2012-01-13 16:59:52 --> Could not find the language line "home"
ERROR - 2012-01-13 16:59:52 --> Could not find the language line "away"
ERROR - 2012-01-13 17:00:07 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:00:26 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-13 17:00:26 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-13 17:00:30 --> Could not find the language line "home"
ERROR - 2012-01-13 17:00:30 --> Could not find the language line "away"
ERROR - 2012-01-13 17:00:30 --> Could not find the language line "home"
ERROR - 2012-01-13 17:00:30 --> Could not find the language line "away"
ERROR - 2012-01-13 17:16:34 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:16:41 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:25:55 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:26:23 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:26:23 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\prediction_edit.php 51
ERROR - 2012-01-13 17:26:23 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\euro2012\application\views\prediction_edit.php 52
ERROR - 2012-01-13 17:26:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-13 17:30:30 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:30:30 --> Severity: Notice  --> Undefined variable: i C:\xampp\htdocs\euro2012\application\views\prediction_edit.php 52
ERROR - 2012-01-13 17:31:22 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:32:12 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:32:46 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:33:07 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:41:23 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:44:15 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:44:20 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:44:20 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\controllers\predictions.php 869
ERROR - 2012-01-13 17:44:20 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\controllers\predictions.php 871
ERROR - 2012-01-13 17:45:27 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:45:38 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:45:57 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 17:46:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:06:20 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:06:27 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:06:30 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:06:35 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:06:38 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:08:30 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:08:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-13 18:08:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-13 18:09:45 --> Severity: Warning  --> Cannot use a scalar value as an array C:\xampp\htdocs\euro2012\application\controllers\predictions.php 872
ERROR - 2012-01-13 18:09:45 --> Severity: Warning  --> Cannot use a scalar value as an array C:\xampp\htdocs\euro2012\application\controllers\predictions.php 876
ERROR - 2012-01-13 18:09:45 --> Severity: Warning  --> Cannot use a scalar value as an array C:\xampp\htdocs\euro2012\application\controllers\predictions.php 889
ERROR - 2012-01-13 18:09:45 --> Severity: Warning  --> Cannot use a scalar value as an array C:\xampp\htdocs\euro2012\application\controllers\predictions.php 893
ERROR - 2012-01-13 18:09:45 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:09:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-13 18:09:45 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-13 18:13:14 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:26 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:31 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:36 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:39 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:43 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:45 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:13:49 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:15:38 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:15:50 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 179
ERROR - 2012-01-13 18:15:50 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 180
ERROR - 2012-01-13 18:15:50 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 18:16:03 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 179
ERROR - 2012-01-13 18:16:03 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 180
ERROR - 2012-01-13 18:16:04 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 18:16:12 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:16:20 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:16:20 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:16:21 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:16:25 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:16:34 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:16:34 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:16:34 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:17:08 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:17:08 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:17:09 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:19:08 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:19:13 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:19:13 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:19:14 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:20:52 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:21:10 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:21:10 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:21:11 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:23:31 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:23:38 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:23:38 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:23:38 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1023
ERROR - 2012-01-13 18:23:39 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:25:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:25:16 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:25:16 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:25:16 --> Severity: Notice  --> Undefined variable: this_input_post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1024
ERROR - 2012-01-13 18:25:17 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:25:54 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:25:59 --> Severity: Notice  --> Undefined property: CI_Input::$post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 993
ERROR - 2012-01-13 18:25:59 --> Severity: Notice  --> Undefined index: timestamp C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 171
ERROR - 2012-01-13 18:25:59 --> Severity: Notice  --> Undefined property: CI_Input::$post C:\xampp\htdocs\euro2012\application\controllers\predictions.php 1023
ERROR - 2012-01-13 18:26:00 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:26:50 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:26:57 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:27:20 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:27:46 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:27:58 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 18:28:40 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:28:46 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:28:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:28:59 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:29:02 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:29:09 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:29:16 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:29:23 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:57:28 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:57:39 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 18:57:45 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:01:01 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:01:13 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:01:16 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:01:25 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 179
ERROR - 2012-01-13 19:01:25 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 180
ERROR - 2012-01-13 19:01:25 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 19:05:16 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:05:22 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:05:26 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:05:29 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:05:34 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:05:39 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:06:19 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:06:47 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:07:22 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:10:37 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:11:37 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:12:01 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:12:40 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:12:56 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:13:17 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:14:20 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:15:04 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:19:25 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:19:49 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:19:52 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:19:52 --> Could not find the language line ""
ERROR - 2012-01-13 19:19:52 --> Could not find the language line ""
ERROR - 2012-01-13 19:23:43 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:23:43 --> Could not find the language line ""
ERROR - 2012-01-13 19:23:49 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:23:53 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:23:53 --> Could not find the language line ""
ERROR - 2012-01-13 19:25:48 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:27:12 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:27:27 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:27:44 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 179
ERROR - 2012-01-13 19:27:44 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 180
ERROR - 2012-01-13 19:27:44 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-13 19:30:54 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 179
ERROR - 2012-01-13 19:30:54 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 180
ERROR - 2012-01-13 19:39:22 --> Could not find the language line "home"
ERROR - 2012-01-13 19:39:22 --> Could not find the language line "away"
ERROR - 2012-01-13 19:39:22 --> Could not find the language line "home"
ERROR - 2012-01-13 19:39:22 --> Could not find the language line "away"
ERROR - 2012-01-13 19:39:40 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 19:39:45 --> Could not find the language line "home"
ERROR - 2012-01-13 19:39:45 --> Could not find the language line "away"
ERROR - 2012-01-13 19:39:45 --> Could not find the language line "home"
ERROR - 2012-01-13 19:39:45 --> Could not find the language line "away"
ERROR - 2012-01-13 19:39:54 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:09:24 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:12:50 --> Could not find the language line "home"
ERROR - 2012-01-13 20:12:50 --> Could not find the language line "away"
ERROR - 2012-01-13 20:12:50 --> Could not find the language line "home"
ERROR - 2012-01-13 20:12:50 --> Could not find the language line "away"
ERROR - 2012-01-13 20:13:30 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:13:37 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:14:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:15:19 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:15:33 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:22:19 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:23:10 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:23:39 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:24:06 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:24:06 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:24:23 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:24:29 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:28:30 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:30:12 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:30:33 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:30:56 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:31:11 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 20:31:49 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-13 21:35:18 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 21:35:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 22:15:05 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 22:15:05 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 22:25:58 --> Severity: Notice  --> Undefined variable: predcition C:\xampp\htdocs\euro2012\application\views\prediction_edit.php 202
ERROR - 2012-01-13 22:52:04 --> Severity: Warning  --> sprintf() [<a href='function.sprintf'>function.sprintf</a>]: Too few arguments C:\xampp\htdocs\euro2012\application\views\prediction_edit.php 209
ERROR - 2012-01-13 22:54:38 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 22:54:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 22:58:09 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-13 22:58:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
