<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-11 18:37:13 --> Could not find the language line "standings"
ERROR - 2012-01-11 18:37:28 --> Could not find the language line "home_goals"
ERROR - 2012-01-11 18:37:28 --> Could not find the language line "away_goals"
ERROR - 2012-01-11 18:41:04 --> Could not find the language line "home_goals"
ERROR - 2012-01-11 18:41:04 --> Could not find the language line "away_goals"
ERROR - 2012-01-11 18:41:24 --> Could not find the language line "home_goals"
ERROR - 2012-01-11 18:41:24 --> Could not find the language line "away_goals"
ERROR - 2012-01-11 18:53:24 --> Severity: Notice  --> Use of undefined constant match_uid - assumed 'match_uid' C:\xampp\htdocs\euro2012\application\views\admin\admin_matches_edit.php 51
ERROR - 2012-01-11 18:53:24 --> Severity: Notice  --> Use of undefined constant match_uid - assumed 'match_uid' C:\xampp\htdocs\euro2012\application\views\admin\admin_matches_edit.php 51
ERROR - 2012-01-11 18:53:24 --> Severity: Notice  --> Use of undefined constant match_uid - assumed 'match_uid' C:\xampp\htdocs\euro2012\application\views\admin\admin_matches_edit.php 51
ERROR - 2012-01-11 19:03:11 --> Severity: Notice  --> Undefined variable: post_array C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 43
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:02 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:20 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 50
ERROR - 2012-01-11 19:36:20 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 50
ERROR - 2012-01-11 19:36:20 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:20 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:20 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:20 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:20 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:21 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:21 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 50
ERROR - 2012-01-11 19:36:30 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 50
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:36:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:16 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 50
ERROR - 2012-01-11 19:38:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 50
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:38:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:38:40 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:38:40 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:07 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:09 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:39:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:39:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:10 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:10 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:10 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:10 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:10 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:39:12 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:12 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:14 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:39:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:39:15 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:29 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:40:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:30 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:40:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:33 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:40:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:40:38 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:41:19 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:19 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:41:23 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:23 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:41:29 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 52
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:41:29 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:09 --> Could not find the language line "delete_calc"
ERROR - 2012-01-11 19:42:18 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:42:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:42:25 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:42:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 57
ERROR - 2012-01-11 19:47:33 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-11 19:47:33 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-11 19:58:15 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:58:15 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:58:22 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:58:22 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-11 19:58:41 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-11 19:58:41 --> Could not find the language line "edit_prediction_for"
ERROR - 2012-01-11 20:00:52 --> Severity: Warning  --> Missing argument 2 for Standings::show() C:\xampp\htdocs\euro2012\application\controllers\standings.php 85
ERROR - 2012-01-11 20:00:52 --> Severity: Notice  --> Undefined variable: group C:\xampp\htdocs\euro2012\application\controllers\standings.php 95
ERROR - 2012-01-11 20:00:52 --> Severity: Notice  --> Undefined variable: group C:\xampp\htdocs\euro2012\application\controllers\standings.php 107
ERROR - 2012-01-11 20:00:52 --> Could not find the language line ""
ERROR - 2012-01-11 20:02:26 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\controllers\standings.php 107
ERROR - 2012-01-11 20:06:03 --> Could not find the language line "standings"
ERROR - 2012-01-11 20:06:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-11 20:06:39 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-11 22:33:50 --> Could not find the language line "standings"
ERROR - 2012-01-11 22:33:50 --> Could not find the language line "average_goals"
ERROR - 2012-01-11 22:33:50 --> Could not find the language line "total_with_average"
ERROR - 2012-01-11 22:33:55 --> Could not find the language line "standings"
