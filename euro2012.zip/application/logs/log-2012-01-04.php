<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-04 19:47:08 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-04 20:03:51 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-04 20:07:24 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-04 20:10:09 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-04 20:17:41 --> 404 Page Not Found --> predictions/randomizerA
ERROR - 2012-01-04 20:18:04 --> 404 Page Not Found --> predictions/randomizerA
ERROR - 2012-01-04 20:22:24 --> Severity: Notice  --> Undefined property: Predictions::$pool C:\xampp\htdocs\euro2012\application\controllers\predictions.php 540
ERROR - 2012-01-04 20:33:16 --> Severity: Notice  --> Use of undefined constant pos_in_group - assumed 'pos_in_group' C:\xampp\htdocs\euro2012\application\libraries\Pool.php 260
ERROR - 2012-01-04 20:33:16 --> Severity: Notice  --> Use of undefined constant pos_in_group - assumed 'pos_in_group' C:\xampp\htdocs\euro2012\application\libraries\Pool.php 260
ERROR - 2012-01-04 20:33:16 --> Severity: Notice  --> Use of undefined constant pos_in_group - assumed 'pos_in_group' C:\xampp\htdocs\euro2012\application\libraries\Pool.php 260
ERROR - 2012-01-04 20:33:16 --> Severity: Notice  --> Use of undefined constant pos_in_group - assumed 'pos_in_group' C:\xampp\htdocs\euro2012\application\libraries\Pool.php 260
ERROR - 2012-01-04 20:49:49 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-04 21:26:14 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: home_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:26:14 --> Severity: Notice  --> Undefined variable: away_teams C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:26:14 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 1 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 1 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 2 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 2 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 3 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 3 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 4 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 4 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 5 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 5 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 6 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 6 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 7 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 7 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 8 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 8 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 9 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 9 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 10 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 10 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 11 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 11 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 12 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 12 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 13 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 13 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 14 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 14 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 15 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 15 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 16 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 16 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 17 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 17 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 18 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 18 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 19 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 19 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 20 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 20 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 21 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 21 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 22 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 22 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 23 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 23 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 24 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:27:18 --> Severity: Notice  --> Undefined index: 24 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:27:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 1 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 1 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 2 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 2 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 3 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 3 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 4 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 4 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 5 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 5 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 6 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 6 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 7 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 7 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 8 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 8 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 9 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 9 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 10 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 10 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 11 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 11 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 12 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 12 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 13 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 13 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 14 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 14 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 15 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 15 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 16 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 16 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 17 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 17 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 18 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 18 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 19 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 19 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 20 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 20 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 21 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 21 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 22 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 22 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 23 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 23 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 24 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:32:25 --> Severity: Notice  --> Undefined index: 24 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:32:25 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 1 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 1 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 2 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 2 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 3 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 3 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 4 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 4 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 5 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 5 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 6 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 6 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 7 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 7 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 8 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 8 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 9 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 9 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 10 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 10 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 11 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 11 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 12 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 12 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 13 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 13 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 14 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 14 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 15 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 15 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 16 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 16 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 17 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 17 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 18 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 18 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 19 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 19 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 20 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 20 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 21 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 21 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 22 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 22 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 23 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 23 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 24 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 60
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:35:01 --> Severity: Notice  --> Undefined index: 24 C:\xampp\htdocs\euro2012\application\views\predictions_editgroup.php 66
ERROR - 2012-01-04 21:35:01 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\system\helpers\form_helper.php 331
ERROR - 2012-01-04 21:36:02 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:02 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:37 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:36:49 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:45 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:46 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:54 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:37:55 --> Could not find the language line ""
ERROR - 2012-01-04 21:39:18 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:39:29 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:39:53 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:41:50 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:43:09 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:45:13 --> Could not find the language line "ALL"
ERROR - 2012-01-04 21:47:08 --> Could not find the language line "ALL"
