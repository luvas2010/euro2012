<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-03 15:59:15 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-03 15:59:16 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-03 15:59:16 --> Could not find the language line "welcome_maintext"
ERROR - 2012-01-03 15:59:16 --> Could not find the language line "welcometext"
ERROR - 2012-01-03 16:01:31 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-03 16:01:34 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-03 16:09:21 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 16:09:35 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 16:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 7
ERROR - 2012-01-03 16:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 8
ERROR - 2012-01-03 16:17:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 15
ERROR - 2012-01-03 16:17:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 7
ERROR - 2012-01-03 16:17:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 8
ERROR - 2012-01-03 16:17:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\home.php 15
ERROR - 2012-01-03 16:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\account\account_menu.php 6
ERROR - 2012-01-03 16:17:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\views\account\account_menu.php 11
ERROR - 2012-01-03 16:18:27 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-03 16:18:28 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-03 16:18:28 --> Could not find the language line "welcome_maintext"
ERROR - 2012-01-03 16:18:28 --> Could not find the language line "welcometext"
ERROR - 2012-01-03 16:18:53 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-03 16:18:54 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-03 16:48:00 --> Could not find the language line "standings"
ERROR - 2012-01-03 16:50:05 --> Could not find the language line "standings"
ERROR - 2012-01-03 16:50:37 --> Could not find the language line "standings"
ERROR - 2012-01-03 16:50:40 --> Could not find the language line "standings"
ERROR - 2012-01-03 17:15:02 --> Severity: Notice  --> Undefined variable: CI C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 174
ERROR - 2012-01-03 17:15:02 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\euro2012\application\helpers\pool_helper.php 174
ERROR - 2012-01-03 17:36:32 --> Could not find the language line "home_goals"
ERROR - 2012-01-03 17:36:32 --> Could not find the language line "away_goals"
ERROR - 2012-01-03 19:10:15 --> Query error: Duplicate entry 'schop' for key 'username'
ERROR - 2012-01-03 21:06:55 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-03 21:06:56 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-03 21:06:56 --> Could not find the language line "welcome_maintext"
ERROR - 2012-01-03 21:06:56 --> Could not find the language line "welcometext"
ERROR - 2012-01-03 21:07:14 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-03 21:07:15 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-03 21:07:30 --> Could not find the language line "standings"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "check_settings"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "navhome"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "groups"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "nav_matches"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "predictions"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "group"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "quarter_final"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "semi_final"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "final"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "nav_extra"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "all_predictions"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "nav_standings"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "statistics"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "nav_champ_graph"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "nav_totalgoals_graph"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "nav_top_ten"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "adminmenu"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "edit_match_results"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "edit_teams_knockout_phase"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "usermanagement"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "list_all_users"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "show_unverified_users"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "check_settings"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "website_account"
ERROR - 2012-01-03 21:27:01 --> Could not find the language line "website_sign_out"
ERROR - 2012-01-03 21:35:22 --> Severity: Notice  --> Undefined index: language C:\xampp\htdocs\euro2012\application\controllers\account\account_linked.php 22
ERROR - 2012-01-03 21:37:56 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 21:38:05 --> Severity: Notice  --> Undefined index: language C:\xampp\htdocs\euro2012\application\controllers\account\account_linked.php 22
ERROR - 2012-01-03 21:38:11 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 21:48:56 --> Could not find the language line ""
ERROR - 2012-01-03 21:48:56 --> Could not find the language line ""
ERROR - 2012-01-03 21:48:56 --> Could not find the language line ""
ERROR - 2012-01-03 21:48:56 --> Could not find the language line ""
ERROR - 2012-01-03 21:48:56 --> Could not find the language line ""
ERROR - 2012-01-03 21:48:56 --> Could not find the language line ""
ERROR - 2012-01-03 21:49:33 --> Could not find the language line ""
ERROR - 2012-01-03 21:49:33 --> Could not find the language line ""
ERROR - 2012-01-03 21:49:33 --> Could not find the language line ""
ERROR - 2012-01-03 21:49:33 --> Could not find the language line ""
ERROR - 2012-01-03 21:49:33 --> Could not find the language line ""
ERROR - 2012-01-03 21:49:33 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:07 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:07 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:07 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:07 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:07 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:07 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:51 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:51 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:51 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:51 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:51 --> Could not find the language line ""
ERROR - 2012-01-03 21:50:51 --> Could not find the language line ""
ERROR - 2012-01-03 22:15:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'id`' at line 1
ERROR - 2012-01-03 22:16:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER_BY `account`.`username`' at line 1
ERROR - 2012-01-03 22:27:34 --> Could not find the language line "show_all_users"
ERROR - 2012-01-03 22:28:35 --> Could not find the language line "show_all_users"
ERROR - 2012-01-03 22:29:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'GROUP BY `account`.`username`' at line 1
ERROR - 2012-01-03 22:29:56 --> Could not find the language line "show_all_users"
ERROR - 2012-01-03 22:32:01 --> Could not find the language line "show_all_users"
ERROR - 2012-01-03 22:32:55 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 22:33:02 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 22:33:04 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 22:33:39 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 22:34:33 --> Could not find the language line "show_all_users"
ERROR - 2012-01-03 22:34:56 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 22:34:57 --> Could not find the language line "delete_account"
ERROR - 2012-01-03 22:35:36 --> Could not find the language line ""
ERROR - 2012-01-03 22:35:36 --> Could not find the language line ""
ERROR - 2012-01-03 22:35:36 --> Could not find the language line ""
ERROR - 2012-01-03 22:35:36 --> Could not find the language line ""
ERROR - 2012-01-03 22:35:36 --> Could not find the language line ""
ERROR - 2012-01-03 22:35:36 --> Could not find the language line ""
