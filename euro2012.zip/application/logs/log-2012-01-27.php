<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-27 10:17:30 --> Could not find the language line "home"
ERROR - 2012-01-27 10:17:30 --> Could not find the language line "away"
ERROR - 2012-01-27 10:17:30 --> Could not find the language line "home"
ERROR - 2012-01-27 10:17:30 --> Could not find the language line "away"
