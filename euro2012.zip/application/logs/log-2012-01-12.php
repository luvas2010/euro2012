<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-12 16:20:18 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-12 16:20:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-12 16:20:32 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:32 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:35 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:35 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:38 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:38 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:41 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:44 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:44 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:49 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:49 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:20:56 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-12 16:20:56 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-12 16:21:12 --> Could not find the language line "standings"
ERROR - 2012-01-12 16:21:28 --> Severity: Notice  --> Undefined index: save C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:21:28 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 55
ERROR - 2012-01-12 16:37:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 16:43:24 --> Query error: Unknown column 'home_team' in 'where clause'
ERROR - 2012-01-12 16:44:35 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 16:45:07 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 16:45:59 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 16:47:36 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 16:47:50 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 17:05:19 --> Could not find the language line "standings"
ERROR - 2012-01-12 17:05:26 --> Could not find the language line "standings"
ERROR - 2012-01-12 17:05:37 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 17:07:14 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 17:21:26 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 17:23:16 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:03:31 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:05:48 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:06:17 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:07:40 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:08:33 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:09:19 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:10:27 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:16:56 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:23:23 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:23:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:24:54 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:26:02 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:28:35 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:31:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:38:32 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:40:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:40:46 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:41:24 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:42:07 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:42:30 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:44:08 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined index: $team_uid C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:50:09 --> Could not find the language line ""
ERROR - 2012-01-12 18:50:09 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:50:27 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:50:34 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: match C:\xampp\htdocs\euro2012\application\views\navigation.php 33
ERROR - 2012-01-12 18:54:30 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:55:02 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:55:09 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:58:18 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 18:59:15 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:01:58 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:02:07 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:06:41 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:15:49 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:29:30 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:31:53 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:32:03 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:33:01 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 19:33:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:11:11 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:14:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:14:54 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:14:58 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:15:08 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:15:13 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:15:22 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:31:39 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:37:06 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:37:34 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:38:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:38:30 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:39:03 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:39:53 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:40:36 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:40:52 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:40:57 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:03 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:09 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:15 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:21 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:27 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:35 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:41 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:47 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:41:57 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:42:04 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:42:10 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:42:16 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:42:22 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:42:28 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:53:18 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 20:59:00 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:03:18 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:10:33 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:11:33 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:13:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:13:27 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:13:52 --> Severity: Notice  --> Undefined index: delete C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-12 21:13:52 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\controllers\admin\matches_edit.php 49
ERROR - 2012-01-12 21:17:51 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:19:00 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:21:32 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:23:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:25:16 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:28:54 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:30:00 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:30:45 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:31:19 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-12 21:32:10 --> Could not find the language line "home"
ERROR - 2012-01-12 21:32:10 --> Could not find the language line "away"
ERROR - 2012-01-12 21:32:10 --> Could not find the language line "home"
ERROR - 2012-01-12 21:32:10 --> Could not find the language line "away"
ERROR - 2012-01-12 21:33:56 --> Could not find the language line "home"
ERROR - 2012-01-12 21:33:56 --> Could not find the language line "away"
ERROR - 2012-01-12 21:33:56 --> Could not find the language line "home"
ERROR - 2012-01-12 21:33:56 --> Could not find the language line "away"
ERROR - 2012-01-12 21:35:04 --> Could not find the language line "home"
ERROR - 2012-01-12 21:35:04 --> Could not find the language line "away"
ERROR - 2012-01-12 21:35:04 --> Could not find the language line "home"
ERROR - 2012-01-12 21:35:04 --> Could not find the language line "away"
ERROR - 2012-01-12 21:35:32 --> Could not find the language line "home"
ERROR - 2012-01-12 21:35:32 --> Could not find the language line "away"
ERROR - 2012-01-12 21:35:32 --> Could not find the language line "home"
ERROR - 2012-01-12 21:35:32 --> Could not find the language line "away"
ERROR - 2012-01-12 21:35:49 --> Could not find the language line "home"
ERROR - 2012-01-12 21:35:49 --> Could not find the language line "away"
ERROR - 2012-01-12 21:35:49 --> Could not find the language line "home"
ERROR - 2012-01-12 21:35:49 --> Could not find the language line "away"
ERROR - 2012-01-12 22:08:15 --> Could not find the language line "home"
ERROR - 2012-01-12 22:08:15 --> Could not find the language line "away"
ERROR - 2012-01-12 22:08:15 --> Could not find the language line "home"
ERROR - 2012-01-12 22:08:15 --> Could not find the language line "away"
ERROR - 2012-01-12 22:09:04 --> Could not find the language line "home"
ERROR - 2012-01-12 22:09:04 --> Could not find the language line "away"
ERROR - 2012-01-12 22:09:04 --> Could not find the language line "home"
ERROR - 2012-01-12 22:09:04 --> Could not find the language line "away"
ERROR - 2012-01-12 22:09:52 --> Could not find the language line "home"
ERROR - 2012-01-12 22:09:52 --> Could not find the language line "away"
ERROR - 2012-01-12 22:09:52 --> Could not find the language line "home"
ERROR - 2012-01-12 22:09:52 --> Could not find the language line "away"
ERROR - 2012-01-12 22:23:31 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
