<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-25 13:12:39 --> Could not find the language line "home"
ERROR - 2012-01-25 13:12:39 --> Could not find the language line "away"
ERROR - 2012-01-25 13:12:39 --> Could not find the language line "home"
ERROR - 2012-01-25 13:12:39 --> Could not find the language line "away"
