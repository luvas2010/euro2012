<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-05 16:39:13 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-05 16:39:33 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-05 16:49:06 --> Could not find the language line "show_all_users"
ERROR - 2012-01-05 16:50:31 --> Could not find the language line "show_all_users"
ERROR - 2012-01-05 16:50:31 --> Could not find the language line "username"
ERROR - 2012-01-05 16:52:26 --> Could not find the language line "show_all_users"
ERROR - 2012-01-05 16:56:31 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-05 16:56:35 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 16:56:35 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 16:56:42 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 16:56:42 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 16:58:26 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 16:58:26 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 16:58:32 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 16:58:32 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 16:59:40 --> Could not find the language line "standings"
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: pred_total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 50
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: pred_total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 50
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: pred_total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 50
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: pred_total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 50
ERROR - 2012-01-05 17:07:14 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:08:00 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:08:00 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:08:00 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:08:00 --> Severity: Notice  --> Undefined index: total_points C:\xampp\htdocs\euro2012\application\controllers\standings.php 51
ERROR - 2012-01-05 17:08:47 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-05 17:08:47 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 17:08:47 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 17:08:53 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 17:08:53 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 17:09:02 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 17:09:02 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 17:09:08 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 17:09:08 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 17:10:35 --> Could not find the language line "standings"
ERROR - 2012-01-05 17:11:34 --> Could not find the language line "home_goals"
ERROR - 2012-01-05 17:11:34 --> Could not find the language line "away_goals"
ERROR - 2012-01-05 17:11:52 --> Could not find the language line "standings"
ERROR - 2012-01-05 17:14:01 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-05 17:14:03 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-05 17:14:03 --> Could not find the language line "welcome_maintext"
ERROR - 2012-01-05 17:14:03 --> Could not find the language line "welcometext"
ERROR - 2012-01-05 17:14:47 --> Could not find the language line "reset_password_email_sender"
ERROR - 2012-01-05 17:14:48 --> Severity: Warning  --> mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\euro2012\system\libraries\Email.php 1553
ERROR - 2012-01-05 18:14:51 --> Could not find the language line "standings"
ERROR - 2012-01-05 18:23:54 --> 404 Page Not Found --> upgrade/index
ERROR - 2012-01-05 18:24:16 --> 404 Page Not Found --> 
ERROR - 2012-01-05 18:24:24 --> 404 Page Not Found --> upgrade/index
ERROR - 2012-01-05 18:24:45 --> Query error: Duplicate column name 'pred_points_total'
ERROR - 2012-01-05 18:25:35 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away C:\xampp\htdocs\euro2012\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2012-01-05 18:27:02 --> Query error: Duplicate column name 'pred_points_total'
