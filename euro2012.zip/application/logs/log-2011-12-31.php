<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2011-12-31 21:29:05 --> Could not find the language line "home_goals"
ERROR - 2011-12-31 21:29:05 --> Could not find the language line "away_goals"
ERROR - 2011-12-31 21:29:13 --> Could not find the language line "home_goals"
ERROR - 2011-12-31 21:29:13 --> Could not find the language line "away_goals"
ERROR - 2011-12-31 21:29:27 --> Could not find the language line "home_goals"
ERROR - 2011-12-31 21:29:27 --> Could not find the language line "away_goals"
ERROR - 2011-12-31 21:29:29 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\euro2012\application\controllers\results.php 52
ERROR - 2011-12-31 21:29:29 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\euro2012\application\controllers\results.php 52
ERROR - 2011-12-31 21:29:29 --> Severity: Notice  --> Undefined offset: 1 C:\xampp\htdocs\euro2012\application\controllers\results.php 53
ERROR - 2011-12-31 21:29:29 --> Severity: Notice  --> Undefined offset: 2 C:\xampp\htdocs\euro2012\application\controllers\results.php 53
ERROR - 2011-12-31 21:40:52 --> Could not find the language line "standings"
