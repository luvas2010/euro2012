<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2012-01-10 16:12:14 --> Could not find the language line "standings"
ERROR - 2012-01-10 16:31:22 --> 404 Page Not Found --> 
ERROR - 2012-01-10 16:32:11 --> 404 Page Not Found --> 
ERROR - 2012-01-10 16:34:33 --> 404 Page Not Found --> stats/1
ERROR - 2012-01-10 16:34:46 --> Severity: Warning  --> Missing argument 1 for Stats::index() C:\xampp\htdocs\euro2012\application\controllers\stats.php 19
ERROR - 2012-01-10 16:34:46 --> Severity: Notice  --> Undefined variable: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 31
ERROR - 2012-01-10 16:34:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 5
ERROR - 2012-01-10 16:34:52 --> 404 Page Not Found --> stats/1
ERROR - 2012-01-10 17:01:05 --> Severity: Notice  --> Undefined variable: preditions C:\xampp\htdocs\euro2012\application\views\stats_match.php 5
ERROR - 2012-01-10 17:01:05 --> Could not find the language line ""
ERROR - 2012-01-10 17:01:05 --> Severity: Notice  --> Undefined variable: preditions C:\xampp\htdocs\euro2012\application\views\stats_match.php 5
ERROR - 2012-01-10 17:01:05 --> Could not find the language line ""
ERROR - 2012-01-10 18:03:06 --> Severity: Notice  --> Undefined variable: predicitions C:\xampp\htdocs\euro2012\application\views\stats_match.php 102
ERROR - 2012-01-10 18:03:06 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\euro2012\application\views\stats_match.php 102
ERROR - 2012-01-10 18:03:06 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\views\stats_match.php 108
ERROR - 2012-01-10 18:21:12 --> Could not find the language line "email_from_address"
ERROR - 2012-01-10 18:24:03 --> Could not find the language line "standings"
ERROR - 2012-01-10 18:25:05 --> Severity: Notice  --> Undefined index: calculated C:\xampp\htdocs\euro2012\application\views\show_user_pred.php 21
ERROR - 2012-01-10 18:25:05 --> Severity: Notice  --> Undefined index: calculated C:\xampp\htdocs\euro2012\application\views\show_user_pred.php 21
ERROR - 2012-01-10 18:25:05 --> Severity: Notice  --> Undefined index: calculated C:\xampp\htdocs\euro2012\application\views\show_user_pred.php 21
ERROR - 2012-01-10 18:25:05 --> Severity: Notice  --> Undefined index: calculated C:\xampp\htdocs\euro2012\application\views\show_user_pred.php 21
ERROR - 2012-01-10 18:25:05 --> Severity: Notice  --> Undefined index: calculated C:\xampp\htdocs\euro2012\application\views\show_user_pred.php 21
ERROR - 2012-01-10 18:25:05 --> Severity: Notice  --> Undefined index: calculated C:\xampp\htdocs\euro2012\application\views\show_user_pred.php 21
ERROR - 2012-01-10 18:48:28 --> 404 Page Not Found --> stats/view_team
ERROR - 2012-01-10 19:00:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN `prediction`
                            ON `match`.`match_uid` = `predict' at line 5
ERROR - 2012-01-10 19:25:41 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:28:14 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:28:14 --> Could not find the language line "group_stage"
ERROR - 2012-01-10 19:28:14 --> Could not find the language line "$team_uid"
ERROR - 2012-01-10 19:28:54 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:28:54 --> Could not find the language line "group_stage"
ERROR - 2012-01-10 19:30:22 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:30:22 --> Could not find the language line "group_stage"
ERROR - 2012-01-10 19:30:22 --> Severity: Notice  --> Undefined index: win C:\xampp\htdocs\euro2012\application\views\stats_team.php 8
ERROR - 2012-01-10 19:30:22 --> Severity: Notice  --> Undefined index: win C:\xampp\htdocs\euro2012\application\views\stats_team.php 9
ERROR - 2012-01-10 19:31:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:31:05 --> Could not find the language line "group_stage"
ERROR - 2012-01-10 19:32:07 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:39:06 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:40:15 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:40:16 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:16 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:40:16 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:16 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:16 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:23 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:23 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:40:23 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:23 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:23 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:51 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:51 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:40:51 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:51 --> Could not find the language line "css"
ERROR - 2012-01-10 19:40:51 --> Could not find the language line "css"
ERROR - 2012-01-10 19:41:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:41:44 --> 404 Page Not Found --> 
ERROR - 2012-01-10 19:41:47 --> 404 Page Not Found --> 
ERROR - 2012-01-10 19:41:52 --> 404 Page Not Found --> 
ERROR - 2012-01-10 19:42:11 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:42:12 --> 404 Page Not Found --> 
ERROR - 2012-01-10 19:42:12 --> 404 Page Not Found --> 
ERROR - 2012-01-10 19:42:14 --> 404 Page Not Found --> 
ERROR - 2012-01-10 19:42:28 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:43:29 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:45:22 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:46:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:46:20 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:46:56 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:48:07 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:50:32 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:50:59 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:51:41 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:52:47 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:53:25 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:53:47 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:54:11 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:54:24 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:54:36 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:54:57 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:55:32 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:56:39 --> Severity: Notice  --> Undefined variable: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 126
ERROR - 2012-01-10 19:56:53 --> Severity: Warning  --> Missing argument 1 for Stats::view_match() C:\xampp\htdocs\euro2012\application\controllers\stats.php 22
ERROR - 2012-01-10 19:56:53 --> Severity: Notice  --> Undefined variable: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 36
ERROR - 2012-01-10 19:56:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7
ERROR - 2012-01-10 19:57:10 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 19:59:30 --> Severity: Notice  --> Undefined variable: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 126
ERROR - 2012-01-10 19:59:58 --> Severity: Warning  --> Missing argument 1 for Stats::view_match() C:\xampp\htdocs\euro2012\application\controllers\stats.php 22
ERROR - 2012-01-10 19:59:58 --> Severity: Notice  --> Undefined variable: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 36
ERROR - 2012-01-10 19:59:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 7
ERROR - 2012-01-10 20:00:24 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:01:22 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:06:10 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:07:28 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:08:08 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:08:46 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:09:31 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:10:15 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:13:49 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:14:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:17:30 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:18:10 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:19:21 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:23:14 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:25:06 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:25:34 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:26:14 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:27:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:31:18 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:35:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:35:22 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:42:06 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:42:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:43:14 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:43:55 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:44:01 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:45:30 --> Severity: Notice  --> Undefined index: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 137
ERROR - 2012-01-10 20:45:30 --> Severity: Notice  --> Undefined index: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 141
ERROR - 2012-01-10 20:45:30 --> Severity: Notice  --> Undefined index: match_uid C:\xampp\htdocs\euro2012\application\controllers\stats.php 145
ERROR - 2012-01-10 20:45:30 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:47:51 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:52:09 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:54:11 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:55:03 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:56:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:56:48 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 20:57:06 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:09:26 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:09:44 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:10:05 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:10:13 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:10:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:12:35 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:14:20 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:14:27 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:16:54 --> Severity: Notice  --> Undefined variable: team_uid C:\xampp\htdocs\euro2012\application\views\matches.php 29
ERROR - 2012-01-10 21:26:58 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:27:03 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:27:11 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:34:39 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:36:48 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 157
ERROR - 2012-01-10 21:36:48 --> Severity: Warning  --> Division by zero C:\xampp\htdocs\euro2012\application\controllers\stats.php 158
ERROR - 2012-01-10 21:36:48 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:42:44 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:43:09 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:43:40 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:45:42 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:47:55 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:48:06 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:48:27 --> Could not find the language line "standings"
ERROR - 2012-01-10 21:52:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 21:58:19 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:18:07 --> Could not find the language line "ALL"
ERROR - 2012-01-10 22:19:35 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:19:48 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:20:08 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:20:15 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:20:24 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:21:06 --> Could not find the language line "standings"
ERROR - 2012-01-10 22:21:06 --> Could not find the language line "average_goals"
ERROR - 2012-01-10 22:21:06 --> Could not find the language line "total_with_average"
ERROR - 2012-01-10 22:21:19 --> Could not find the language line "standings"
ERROR - 2012-01-10 22:21:26 --> Could not find the language line "standings"
ERROR - 2012-01-10 22:23:47 --> Could not find the language line "standings"
ERROR - 2012-01-10 22:26:12 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:26:27 --> Could not find the language line "ALL"
ERROR - 2012-01-10 22:26:43 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
ERROR - 2012-01-10 22:32:56 --> Could not find the language line "match_avg_goals"
ERROR - 2012-01-10 22:45:11 --> Severity: Notice  --> Undefined variable: predictions C:\xampp\htdocs\euro2012\application\views\stats_team.php 1
