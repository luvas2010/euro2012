<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| Others
|--------------------------------------------------------------------------
*/
$config['pool_version'] = '1.2'; 

/* End of file other.php */
/* Location: ./application/config/other.php */


