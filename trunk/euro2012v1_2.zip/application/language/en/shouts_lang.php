<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['all_shouts']								= 'All messages';
$lang['shout_header']							= "%s said on %s at %s:";
$lang['delete_shout']							= 'Delete';

/* End of file sign_in_lang.php */
/* Location: ./application/language/en/shouts_lang.php */
