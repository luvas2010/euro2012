<?php

$lang['username']       = "User Name";
$lang['points_total']	= "Points";
/* End of file standings_lang.php */
/* Location: ./application/language/english/standings_lang.php */
