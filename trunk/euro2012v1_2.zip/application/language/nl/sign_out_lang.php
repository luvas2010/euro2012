<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Signout
|--------------------------------------------------------------------------
*/
$lang['sign_out_successful']						= 'Ok, je bent uitgelogd.';
$lang['sign_out_go_to_home']						= 'Ga naar de homepage';


/* End of file sign_out_lang.php */
/* Location: ./application/modules/account/language/nl/sign_out_lang.php */