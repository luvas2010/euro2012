<?php

$lang['username']       = "Gebruikersnaam";
$lang['points_total']	= "Punten";
/* End of file standings_lang.php */
/* Location: ./application/language/english/standings_lang.php */
