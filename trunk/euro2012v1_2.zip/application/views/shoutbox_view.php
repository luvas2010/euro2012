<?php

foreach ($shouts as $shout)
{
    echo $shout['message'];
}
?>