<div class="container_12">
    <div id='manual' class="grid_12 alpha omega">
        <iframe src="https://docs.google.com/document/pub?id=1LCVnpbZn7_mXoJh55wMub6ivmwqIJC1Lyy6Uc-1232M" scrolling='no'></iframe>
    </div>    
</div>
